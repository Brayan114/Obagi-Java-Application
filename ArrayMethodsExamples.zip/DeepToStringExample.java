
import java.util.Arrays;

public class DeepToStringExample {
    public static void main(String[] args) {
        int[][] deepArray = {{1, 2}, {3, 4}};
        System.out.println("Deep to string: " + Arrays.deepToString(deepArray));
    }
}
