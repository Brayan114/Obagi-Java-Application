
import java.util.Arrays;

public class ToStringExample {
    public static void main(String[] args) {
        int[] numbers = {10, 20, 30};
        System.out.println("Array to string: " + Arrays.toString(numbers));
    }
}
